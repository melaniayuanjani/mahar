tailwind.config = {
      theme: {
        extend: {
          colors: {
            maroon: {
              50: '#fdf3f4',
              100: '#fbe8ea',
              600: '#8e233c',
              700: '#6b1d2f',
              800: '#521422',
              900: '#380a14'
            },
            gold: {
              50: '#fdfbf3',
              100: '#fbf5df',
              400: '#e5be62',
              500: '#d4a237',
              600: '#b88523',
              700: '#916314'
            },
            canvas: '#fcf9f4'
          },
          fontFamily: {
            serif: ['"Playfair Display"', 'serif'],
            sans: ['"Plus Jakarta Sans"', 'sans-serif']
          }
        }
      }
    }
